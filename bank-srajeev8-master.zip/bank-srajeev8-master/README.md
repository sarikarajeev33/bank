# Bank Lab

You have been given some code to manage a bank and associated bank accounts. However, the code has issues!

# What to do
1. Compile the code.
2. Run the code.
3. Look at **memwatch.log**.
4. Does it report no problems?
5. If there are problems:
    1. Attempt to fix them
    2. Return to step 1.
6. Otherwise:
    1. Bask in a job well done.
